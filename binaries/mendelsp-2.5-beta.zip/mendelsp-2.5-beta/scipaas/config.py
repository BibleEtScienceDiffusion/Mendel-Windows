# USER AUTHENTICATION
auth = False
configurable = False

# the number of lines to show while monitoring 
tail_num_lines = 24

# the number of rows to show at a time in the jobs table
jobs_num_rows = 20

# DATABASE
db = 'scipaas.db'
dbdir = 'db'
uri = 'sqlite://'+db

# DIRECTORIES
apps_dir = 'apps'
user_dir = 'user_data'
upload_dir = '_uploads'
tmp_dir = 'static/tmp'
mpirun = '/usr/local/bin/mpirun'

# SCHEDULER
# uniprocessor scheduling -- for single-core machines
sched = 'uni'
# schedule more than one job at a time (multiprocessor)
#sched = 'smp'
# number of processors available to use on this machine
np = 2

# WEB SERVER
# don't define server if you want to use built-in
# other options: cherrypy, bjoern, tornado, gae, etc.
# cherrypy is a decent multi-threaded server
#server = 'cherrypy'
port = 8580
