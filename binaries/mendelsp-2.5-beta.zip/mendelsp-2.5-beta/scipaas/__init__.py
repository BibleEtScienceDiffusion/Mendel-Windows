__author__ = 'Wesley Brewer'
__version__ = '0.10.0'
__license__ = 'MIT'
